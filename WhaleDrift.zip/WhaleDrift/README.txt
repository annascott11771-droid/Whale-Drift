# Whale Drift  v2.0

A 2D endless underwater runner. Guide a whale through sunlit reefs, twilight
canyons and abyssal trenches, slipping between tapered spikes, drifting urchins
and fast currents. Collect pearls, bubble shields and current boosts. Six
difficulties, gamepad and touch support, and a deliberately slow speed ramp.
Built with Godot 4.7.2.

## Run on Windows

Double-click WhaleDrift.exe. No installation required.

## Android

Copy WhaleDrift.apk to a phone or tablet, allow installation from unknown
sources, then install and launch **Whale Drift**.

- Android 7.0 (API 24) or newer, arm64 only
- versionName 2.0 / versionCode 4
- Signed with a debug key for direct installation (not for Google Play)
- Landscape, immersive fullscreen

## Health and bubbles

The bar holds **6 points**, drawn as **3 hearts** (2 points per heart). Each
heart can show full, three-quarter, half, quarter or empty, so the display
always matches the real value.

- A clean hit costs **1 point** = **half a heart**
- A bubble **soaks half of one hit** and is used up
- Collect another bubble while one is active to **add a layer** (max 6)
- Layers expire after the shield duration; picking one up refreshes it
- The bubble aura is a bright ring plus one bubble per layer around the whale

## Talent shop (new in 2.0)

Open **TALENT SHOP** from the main menu. Pearls are earned at the end of every
run and are spent on permanent upgrades:

| Talent | Effect | Prices |
|---|---|---|
| Shield time | Bubble shield lasts 3.0 s → 5.0 s | 50 / 120 / 250 / 500 |
| Dash range | Dash power 100 → 180 (longer burst) | 60 / 140 / 280 / 560 |
| Pearl magnet | Pull radius 0 → 200 px | 80 / 180 / 360 / 720 |

- Each talent has 5 levels; at level 5 the button turns grey and shows **MAX**
- If you cannot afford an upgrade the row flashes red and shakes
- Progress is saved to `user://save_data.cfg` and restored on launch

### How pearls are paid out

```
depth   = floor(distance / 100)              # 1 pearl per 100 m
pickups = min(collected, 12)                 # up to 12 counted
score   = 0, or 1 + floor((score-100000)/50000) when score >= 100000 (max 10)
total   = min(depth + pickups + score, 50)   # hard cap per run
```

A typical 1200 m run with 20 pearls collected pays **24 pearls**, so the first
talent costs about 2–3 runs and the full ladder takes 15–20 runs.

## Controls

Windows:

| Action | Input |
|---|---|
| Move up / down | W / S or arrow keys |
| Dash (invulnerable) | SHIFT / SPACE |
| Pause | ESC / P |
| Mute | M |
| Fullscreen | F11 |
| Switch language | L |

Gamepad: left stick / D-pad to move and navigate, A / X / RB / RT to dash,
A to confirm, B to go back, START to pause.

Touch:

| Action | Input |
|---|---|
| Move | Drag anywhere in the play area |
| Dash | Round DASH button, bottom-right |
| Pause | Button, bottom-left |
| Menus / shop | Tap |

## Language

The game starts in English. Switch with **Settings → LANGUAGE** (tap the right
half of the row) or press **L** on Windows.

On phones and tablets the **Display mode** and **Resolution** rows are hidden
because the OS owns the window size. The layout expands to fill tablets instead
of adding bars.

## Frame rate

The FPS counter reads the engine's own measurement, so it matches the real
frame rate. Vsync is only disabled when your cap is below the panel refresh
rate, which is what makes an explicit cap reachable.

## Defaults

- Difficulty: Blue Wanderer (Normal)
- Window: 1280×720 windowed (desktop) / fullscreen (mobile)
- FPS limit: 60
- Steering sensitivity: 100%
- Master volume: 80%
- Screen shake: on, FPS counter: off

## Save data

```text
%APPDATA%\Godot\app_userdata\Whale Drift\
  whale_save.json     records and checkpoint
  whale_settings.json video / audio / language
  save_data.cfg       pearls and talent levels
```

Delete the folder to reset everything.
On Android, use the system "clear data" option for the app.

## Credits

Game code, design and art created for Whale Drift. UI font: Noto Sans SC
(SIL Open Font License). Engine: Godot 4.7.2.
